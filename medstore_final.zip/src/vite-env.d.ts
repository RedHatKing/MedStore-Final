interface ImportMetaEnv {
  // Add other environment variables here if needed
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}